package com.klef.jfsd.exom.service;

import com.klef.jfsd.exom.model.Project;
import com.klef.jfsd.exom.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;

import java.text.DecimalFormat;

public class ProjectService {
    private final DecimalFormat currencyFormat = new DecimalFormat("#,##0.00");
    
    public void insertSampleData() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            // Create sample projects with more diverse data
            Project[] projects = {
                new Project("E-Commerce Platform", 12, 150000.0, "John Doe", 8, "In Progress"),
                new Project("Mobile App Development", 6, 75000.0, "Jane Smith", 5, "Planning"),
                new Project("Cloud Migration", 9, 200000.0, "Bob Wilson", 12, "In Progress"),
                new Project("AI Implementation", 18, 300000.0, "Alice Brown", 15, "Not Started"),
                new Project("Security Upgrade", 4, 50000.0, "Charlie Davis", 3, "Completed"),
                new Project("Data Analytics Platform", 8, 125000.0, "Eva Green", 7, "In Progress"),
                new Project("IoT Integration", 15, 250000.0, "Mike Johnson", 10, "Planning")
            };

            // Save projects
            for (Project project : projects) {
                session.save(project);
            }

            tx.commit();
            printDivider();
            System.out.println("✅ Sample data inserted successfully!");
            System.out.println("📊 Added " + projects.length + " projects to the database");
            printDivider();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void performAggregateOperations() {
        Session session = HibernateUtil.getSessionFactory().openSession();

        try {
            printDivider();
            System.out.println("📈 AGGREGATE OPERATIONS RESULTS");
            printDivider();

            // Count of projects
            Criteria countCriteria = session.createCriteria(Project.class);
            countCriteria.setProjection(Projections.count("id"));
            Long projectCount = (Long) countCriteria.uniqueResult();
            System.out.println("📌 Total Projects: " + projectCount);

            // Maximum budget
            Criteria maxCriteria = session.createCriteria(Project.class);
            maxCriteria.setProjection(Projections.max("budget"));
            Double maxBudget = (Double) maxCriteria.uniqueResult();
            System.out.println("💰 Highest Budget: $" + currencyFormat.format(maxBudget));

            // Minimum budget
            Criteria minCriteria = session.createCriteria(Project.class);
            minCriteria.setProjection(Projections.min("budget"));
            Double minBudget = (Double) minCriteria.uniqueResult();
            System.out.println("💵 Lowest Budget: $" + currencyFormat.format(minBudget));

            // Sum of budgets
            Criteria sumCriteria = session.createCriteria(Project.class);
            sumCriteria.setProjection(Projections.sum("budget"));
            Double totalBudget = (Double) sumCriteria.uniqueResult();
            System.out.println("🏦 Total Budget: $" + currencyFormat.format(totalBudget));

            // Average budget
            Criteria avgCriteria = session.createCriteria(Project.class);
            avgCriteria.setProjection(Projections.avg("budget"));
            Double avgBudget = (Double) avgCriteria.uniqueResult();
            System.out.println("📊 Average Budget: $" + currencyFormat.format(avgBudget));

            printDivider();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    private void printDivider() {
        System.out.println("================================================");
    }
}