package com.klef.jfsd.exom.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "projects")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "project_name", nullable = false)
    private String projectName;

    @Column(nullable = false)
    private Integer duration; // in months

    @Column(nullable = false)
    private Double budget;

    @Column(name = "lead_name", nullable = false)
    private String leadName;

    @Column(name = "team_size")
    private Integer teamSize;

    @Column(name = "project_status")
    private String status;

    // Constructor with all fields except ID
    public Project(String projectName, Integer duration, Double budget, String leadName, Integer teamSize, String status) {
        this.projectName = projectName;
        this.duration = duration;
        this.budget = budget;
        this.leadName = leadName;
        this.teamSize = teamSize;
        this.status = status;
    }

    // Constructor with required fields
    public Project(String projectName, Integer duration, Double budget, String leadName) {
        this(projectName, duration, budget, leadName, null, null);
    }
}