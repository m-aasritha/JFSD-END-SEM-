package com.klef.jfsd.exom;

import com.klef.jfsd.exom.service.ProjectService;
import com.klef.jfsd.exom.util.HibernateUtil;

public class ClientDemo {
    public static void main(String[] args) {
        ProjectService projectService = new ProjectService();

        // Insert sample data
        projectService.insertSampleData();

        // Perform aggregate operations
        projectService.performAggregateOperations();

        // Clean up
        HibernateUtil.shutdown();
    }
}